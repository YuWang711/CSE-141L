To run my ISA design, use the program123_tb.sv as the top level test bench.
 I decided that my ISA can only branch up to 256 lines, therefore, you would have to compile each program
through the command python assem_compiler.py p1_assem.txt or python assem_compiler.py p2_assem.txt or
python assem_compiler.py p3_assem.txt before you run the testbench. 

To run each program, uncomment that program from the test bench and comment out the other programs.
Also leave the reset uncomment in the middle of the program 1 codes.

If you run into the program where my program counter is stuck at zero.
Please uncomment the #10ns reset = 1; in the testbench program 1 codes or add it in yourself 
where it is appropriate.

As for testing goes. I gone with A- because 
I did not want to try and fix program 3.
Program 3 will work with given cases pat = 00000 and memory been 00000000
however, it won't work perfectly with random. Only counting with cross bytes will
work with random. The other two will get a different value.
Program 1 and 2 should work perfectly.

My ISA design uses three types of format

[ 4 bits opcode] [ 3 bits rs ] [ 2 bits rt ]	R-format
[ 4 bits opcode] [ 5 bits immediate        ]	IMM-format
[ 4 bits opcode] [ 3 bits rs ] [ 2 bits imm] 	ALU IMM-format

I have up to 16 operations, with one hidden.
Since I used 3 bits for register rs, i have access of 
up to 8 registers, however, only rs can access all 8 register.
Detailed description is also included in Control.sv

IMM	uses IMM format, takes in an immediate and store it in 
	register 0.
CPY	register Copy value in register rt to register rs.

ST 	storing value from register rt into address in register rs.
	
LD	writing value from the memory where the address is store in register rs,
	 and load that value to register rt.
Branch	Branch to a PC where the PC value is store in a register rs.

BNEQZ   Branch to PC of the value in RS If register RT is != 0

IND     Take a value in register RT indexed by the value in register RS and overwrite 
	it to Register RS.

ADDI	Only used for iterations. add a value immediately to a register, value range from 0-3

XOR	Xor most significant 7 bit in register RS and store at least significant bit of rs.

SHL	shift register RS by value of RT.

MSHL	Take the most significant bit of RT and shift left into register RS.

SUBI	subtract value in register rs by rt value.

FLIP	Flip the bit of register rs that correspond to the indices value of rt.

CMP	Compare last 5 bits of register rs and register rt, 
	if they are equal, change the MSB to 1 if not change MSB to 0 in register RS

EXIT	Signaling done.