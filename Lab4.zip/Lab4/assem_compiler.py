import sys

def decimalToBinary(n):  
    return bin(n).replace("0b", "")  

assem = open("./" + sys.argv[1], "r")
mach = open("./mach_code.txt", "w")
mach.write("111000000\n")
for line in assem:
    command = line.split()
    command[1] = int(command[1])
    if(len(command) > 2):
        command[2] = int(command[2])
    if(command[0] == 'IMM'):
        mach.write("0000")
        t = decimalToBinary(command[1])
        while(len(t) < 8):
            t = '0' + t
        mach.write("0" + t[4:8] + "\n")
        mach.write("00001" + t[0:4] + "\n")
    if(command[0] == 'CPY'):
        mach.write("0001")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'ST'):
        mach.write("0010")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'LD'):
        mach.write("0011")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'Branch'):
        mach.write("0100")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        mach.write("00\n")
    if(command[0] == 'BNEQZ'):
        mach.write("0101")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'IND'):
        mach.write("0110")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'ADDI'):
        mach.write("0111")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'XOR'):
        mach.write("1000")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        mach.write("00\n")
    if(command[0] == 'SHL'):
        mach.write("1001")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'MSHL'):
        mach.write("1010")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'SUBI'):
        mach.write("1011")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'FLIP'):
        mach.write("1100")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
    if(command[0] == 'EXIT'):
        mach.write("111100000\n")
    if(command[0] == 'CMP'):
        mach.write("1101")
        t = decimalToBinary(command[1])
        while(len(t) < 3):
            t = '0' + t
        mach.write(t)
        t = decimalToBinary(command[2])
        while(len(t) < 2):
            t = '0' + t
        mach.write(t + "\n")
mach.write("111100000\n")
assem.close()
mach.close()


